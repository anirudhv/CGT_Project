<?php
Hello, I am Robin and I am learning how to implement php
?>

<?php
$x = 5;
$y = 10;

$sum = $x + $y;

echo $sum;
?>
